from astropy.coordinates import SkyCoord as SC
import numpy as np
import os
import sys
import pandas as pd
from astropy.wcs import WCS
from astropy import units as u

# Check if the argument is provided
if len(sys.argv) < 2:
    print("Usage: python3 rename.py <path_to_duplicate_free_csv_file>")
    sys.exit(1)

# The second argument in sys.argv is the path to the CSV file
component_file_path = sys.argv[1]

def skycoord2(data,RA1,DEC1):
    #Extracting the coordinates from the catalogs
    RA=list(map(str,data[RA1]))
    DEC=list(map(str,data[DEC1]))
    coordinates=SC([i+' '+j for i,j in zip(RA,DEC)],unit=(u.deg,u.deg))
    return coordinates

def extract_component_name(filename, prefix):
    match = re.search(pattern, filename)
    if match:
        return f"{prefix} {match.group()}"
    else:
        return None

def convert_ra_dec_to_degrees(ra_dec_str):
    ra_str, dec_str = ra_dec_str.split(' ', 3)[:3], ra_dec_str.split(' ', 3)[3:]
    ra = ' '.join(ra_str)
    dec = ' '.join(dec_str)
    coord = SC(ra, dec, unit=(u.hourangle, u.deg))
    return coord.ra.deg, coord.dec.deg


def crossmatch(data_1,data_2,RA1,DEC1,RA2,DEC2,searchrad):  #the radius is in arcsec
    
    coordinates_1=skycoord2(data_1,RA1,DEC1)
    coordinates_2=skycoord2(data_2,RA2,DEC2)
    
    # identifying the nearest source in 2nd catalog to every source in 1st catalog
    index,dist2d,dist3d = coordinates_1.match_to_catalog_sky(coordinates_2)
    
    
    # identifying sources within a search radius of searchradius
    ifst=dist2d.arcsec<searchrad
    match,index1,dist2d1=np.where(ifst,True,False),np.where(ifst,index,np.nan),np.where(ifst,dist2d,np.nan)
    
    
    # adding the index and the distance column to the first catalog
    # data_1.add_column(1,name='index')
    # data_1.add_column(1,name='dist2d')
    data_1['dist2d']=dist2d1*u.arcsec
    data_1['indexx']=index1
    
    # adding the index column to the second catalog
    # data_2.add_column(1,name='index')
    index_ql=[i for i in range(len(data_2))]
    data_2['indexx']=index_ql
    
    # Joining the first and second tables based on the index 
    data_matched=pd.merge(data_1,data_2,on='indexx',how='inner')
    
    
    #keeping only the relevant columns
    # data_matched.keep_columns([RA1,DEC1,'dist2d','Total_flux_source','Total_flux','Isl_Total_flux'])
    # data_matched['Isl_Total_flux']=data_matched['Isl_Total_flux']*1e3 *u.mJy
    return data_matched,match



import os
import pandas as pd
import re

# Define the regex pattern for RA and DEC extraction
pattern = r'J\d{6}\.\d{2}-\d{6}\.\d{1}'

# Function to extract RA and DEC from filename and create component name

# Directory containing FITS files
directory = "data_out/VLASS"

# File path for the component file

df = pd.read_csv(component_file_path)
prefix = df['Component_name'][0].split()[0]

# Prepare a new dataframe to store data from filenames
filename_data = []

# Process the files
for filename in os.listdir(directory):
    component_name = extract_component_name(filename, prefix)
    if component_name:
        filename_data.append([filename, component_name])

# Create a new DataFrame from the filename data
filename_df = pd.DataFrame(filename_data, columns=['Filename', 'Component_name'])
filename_df['m1ra']=[i[13:22] for i in filename_df['Component_name']]
# len('VLASS3QLCIR J000958.47')
df['m1radec']=[i[13:15]+' '+i[15:17]+' '+i[17:22]+' '+i[22:25]+' '+i[25:27]+' '+i[27:31] for i in df['Component_name']]
filename_df['m1radec']=[i[13:15]+' '+i[15:17]+' '+i[17:22]+' '+i[22:25]+' '+i[25:27]+' '+i[27:31] for i in filename_df['Component_name']]


# df['m1radec'],filename_df['m1radec']

#  DEC to degrees

# Convert and update the DataFrame
for index, row in df.iterrows():
    ra_deg, dec_deg = convert_ra_dec_to_degrees(row['m1radec'])
    df.at[index, 'm1ra'] = ra_deg
    df.at[index, 'm1dec'] = dec_deg

# print(df)
df
# Convert and update the DataFrame
for index, row in filename_df.iterrows():
    ra_deg, dec_deg = convert_ra_dec_to_degrees(row['m1radec'])
    filename_df.at[index, 'm1ra'] = ra_deg
    filename_df.at[index, 'm1dec'] = dec_deg
# filename_df




merged_df=crossmatch(df,filename_df,'m1ra','m1dec','m1ra','m1dec',0.2)[0]
# Rename 'Component_name_x' to 'Component_name'
merged_df.rename(columns={'Component_name_x': 'Component_name'}, inplace=True)

# Columns to be removed
columns_to_remove = ['m1radec_x', 'm1ra_x', 'm1dec_x', 'dist2d', 'indexx',  
                     'Component_name_y', 'm1ra_y', 'm1radec_y', 'm1dec_y']

# Remove the specified columns
merged_df.drop(columns=columns_to_remove, inplace=True, errors='ignore')
# merged_df.to_csv(component_file_path.rstrip('.csv')+'merged_output.csv',index=False)

print("Merging complete.")





# Load the DataFrame from CSV
df=merged_df #= pd.read_csv('/path/to/your/dataframe.csv')

# Directory containing the files to be renamed

# Iterate through the DataFrame
for index, row in df.iterrows():
    component_name = row['Component_name']
    coordinates = component_name.split(' ')[1]  # Extract the coordinates part
    new_filename = f"{coordinates}_VLASS.fits"

    # Original filename (assuming it's stored in the DataFrame)
    original_filename = row['Filename']

    # Full paths for original and new filenames
    original_filepath = os.path.join(directory, original_filename)
    new_filepath = os.path.join(directory, new_filename)

    # Check if the original file exists and rename it
    if os.path.exists(original_filepath):
        os.rename(original_filepath, new_filepath)
#         print(original_filepath, new_filepath)
    else:
        print(f"File not found: {original_filepath}")

print("Renaming complete.")