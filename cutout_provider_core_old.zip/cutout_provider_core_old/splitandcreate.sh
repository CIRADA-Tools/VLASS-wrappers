#!/bin/bash

# Specify the original filename
ORIGINAL_FILENAME="VLASS3QLCIR_components_duplicate_free.csv"
SPLIT_PREFIX="xyz" # Prefix for split files
FILE_BASENAME=`echo ${ORIGINAL_FILENAME%.*}`

# Split the original file
HDR=$(head -1 $ORIGINAL_FILENAME)
split -l 50000 $ORIGINAL_FILENAME $SPLIT_PREFIX
n=1
for f in ${SPLIT_PREFIX}*
do
  SPLIT_FILENAME="${FILE_BASENAME}_${n}.csv"
  echo $HDR > $SPLIT_FILENAME
  cat $f >> $SPLIT_FILENAME
  rm $f

  # Now process the split file with create.py
  start=`date +%s`
  echo "Processing $SPLIT_FILENAME"
  python3 -u create.py $SPLIT_FILENAME
  end=`date +%s`
  echo "Time taken: $((end-start)) seconds"

  (( n++ ))
done
python3 rename.py $ORIGINAL_FILENAME