import sys
import pandas as pd
import subprocess
from threading import Thread
from time import perf_counter
f1 = sys.argv[1]
f = open('abcd.txt','a')
def get_cuts(ra , dec, dups):
    print(f"dups value: {dups}, type: {type(dups)}")
    if float(dups) == 0.0 or float(dups) == 1.0:
        str1 = "python3 fetch_cutouts.py fetch -r 1.5 -g mosaic -c %s,%s -s VLASS" %(ra,dec)
        print(str1)
        try:
            subprocess.call(str1,shell=True)
        except Exception  as e:
            f.write(f"{e}, {ra}, {dec}\n")
            print(e, ra, dec)
            pass
    else:
        pass

df1 = pd.read_csv(f1)
# list1 = list(zip(df1.RA,df1.DEC,df1.Duplicate_flag))
list1 = list(zip(df1.RA, df1.DEC, df1.Duplicate_flag))[1:]  # Skip header
l = len(list1)
start_time = perf_counter()        
threads = []
for j in range(0, l, 20):
    list2 = list1[j:j + 20]
    for i in range(len(list2)):  # Change here
        a, b, c = list2[i][0], list2[i][1], list2[i][2]
        print(a,b,c)
        t = Thread(target=get_cuts, args=(a, b, c))
        threads.append(t)
        t.start()

        for t in threads:
            try:
                t.join()
            except Exception as e:
                print(e)
                pass

        end_time = perf_counter()

        print(f'It took {end_time-start_time: 0.2f} seconds to do')

f.close()
        
